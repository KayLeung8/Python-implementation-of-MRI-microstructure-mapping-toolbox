import matplotlib.pyplot as plt
import numpy as np

# Set image dimensions
imgdim = (20, 20, 1)

# Define mask
mask = np.ones(imgdim)

# Number of spectral components
ncomp = 4

# Set volume fractions across image
vfimg = np.zeros(imgdim + (ncomp,))
vfimg[:, :, :, 0] = np.tile(np.linspace(0, 0.5, imgdim[0])[:, np.newaxis, np.newaxis], (1, imgdim[1], 1))
vfimg[:, :, :, 1] = np.tile(np.linspace(0, 0.5, imgdim[0])[:, np.newaxis, np.newaxis], (1, imgdim[1], 1))
vfimg[:, :, :, 2] = np.abs(1 - np.sum(vfimg[:, :, :, 0:2], axis=3, keepdims=True)).squeeze(-1)
vfimg[:, :, :, 3] = vfimg[:, :, :, 2].copy()
vfimg[:, :, :, 2] = np.tril(vfimg[:, :, :, 2][:, :, 0], -1)[:, :, np.newaxis]
vfimg[:, :, :, 3] = np.triu(vfimg[:, :, :, 3][:, :, 0])[:, :, np.newaxis]

# Normalize
vfimg /= np.sum(vfimg, axis=3, keepdims=True)

# Create image layout
fig, axs = plt.subplots(2, 2, figsize=(12, 10))
axs = axs.flatten()

for i in range(ncomp):
    rotated_image = np.rot90(vfimg[:, :, 0, i])  # Rotate 90 degrees to the left
    im = axs[i].imshow(rotated_image, cmap='viridis')  # Use 'viridis' color map
    axs[i].set_title(f'Component {i + 1}')
    axs[i].axis('off')

# Add an additional axes for the color bar and adjust its position
cbar_ax = fig.add_axes([0.92, 0.15, 0.03, 0.7])  # This position can be adjusted according to the layout
fig.colorbar(im, cax=cbar_ax)

plt.tight_layout(rect=[0, 0, 0.9, 1])  # Adjust the layout to make room for color bars
plt.show()
