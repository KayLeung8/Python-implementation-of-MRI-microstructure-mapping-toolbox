import numpy as np
import matplotlib.pyplot as plt

# Set image dimensions
imgdim = (100, 100, 1)
# Define mask
mask = np.ones(imgdim)
# Number of spectral components
ncomp = 4
# Set volume fractions across image
vfimg = np.zeros(imgdim + (ncomp,))
vfimg[:, :, :, 0] = np.tile(np.linspace(0, 0.5, imgdim[0])[:, np.newaxis, np.newaxis], (1, imgdim[1], 1))
vfimg[:, :, :, 1] = np.tile(np.linspace(0, 0.5, imgdim[0])[:, np.newaxis, np.newaxis], (1, imgdim[1], 1))
vfimg[:, :, :, 2] = np.abs(1 - np.sum(vfimg[:, :, :, 0:2], axis=3, keepdims=True)).squeeze(-1)
vfimg[:, :, :, 3] = vfimg[:, :, :, 2].copy()
vfimg[:, :, :, 2] = np.tril(vfimg[:, :, :, 2][:, :, 0], -1)[:, :, np.newaxis]
vfimg[:, :, :, 3] = np.triu(vfimg[:, :, :, 3][:, :, 0])[:, :, np.newaxis]

# Normalize
vfimg /= np.sum(vfimg, axis=3, keepdims=True)


# Reading data
def load_gradechoinv(filename):
    return np.loadtxt(filename)


# Kernel computation function
def KernelMeas(kernel, data):
    d = kernel['params'][0]  # ADC values
    t2 = kernel['params'][1]  # T2 values
    b = data[:, 3]
    te = data[:, 4]
    return np.exp(-data[:, 1] * d) * np.exp(-data[:, 2] / t2)


# Add noise
def add_noise(signal, SNR, noisetype='gaussian'):
    if noisetype == 'gaussian':
        noise = np.random.normal(0, 1 / SNR, signal.shape)
    return signal + noise


# Analog image
def process_data(imgdim, vfimg, spectral_comp, gradechoinv):
    SNR = 50  # Signal to Noise Ratio
    for x in range(imgdim[0]):
        for y in range(imgdim[1]):
            for z in range(imgdim[2]):
                f = vfimg[x, y, z, :]
                S = 0
                for i in range(len(f)):
                    kernel['params'] = spectral_comp[:, i]
                    S += f[i] * KernelMeas(kernel, gradechoinv)
                # Normalization
                b0teminindex = 0
                S = S / S[b0teminindex]
                # Add noise
                S = add_noise(S, SNR)
                # Assign a value to the image
                simimg[x, y, z, :] = S
    return simimg


# Data loading
gradechoinv_filename = 'placenta_gradechoinv.txt'
gradechoinv = load_gradechoinv(gradechoinv_filename)

# Set kernel
kernel = {'name': 'DT2'}

# Define the typical spectral components
d = np.array([0.0002, 0.003, 0.05, 0.2])  # ADC
t2 = np.array([50, 60, 70, 80])  # T2
spectral_comp = np.vstack((d, t2))

# Pre-assign analog images
# imgdim = (20, 20, 1)
# Generates a new array of the given shape
simimg = np.zeros(imgdim + (len(gradechoinv),))

simimg = process_data(imgdim, vfimg, spectral_comp, gradechoinv)
print(np.shape(vfimg))
xtrain = np.reshape(simimg, (10000, 330))
ytrain = np.reshape(vfimg, (10000, 4))

from sklearn.ensemble import RandomForestRegressor
clf = RandomForestRegressor(random_state=0)
# X = [[ 1,  2,  3],  # 2 samples, 3 features
#      [11, 12, 13]]
# y = [0, 1]  # classes of each sample
clf.fit(xtrain, ytrain)
print(clf.predict(xtrain))
print(ytrain)



plt.figure(figsize=(10, 10))  # Set image size
plt.imshow(simimg[:, :, 0, 10], cmap='viridis')  # Displays an image of the first slice, using viridis color mapping

plt.colorbar()  # Display color bar
plt.title('Simulated MR Image')  # Set image title
plt.axis('off')  # Do not display coordinate axes
plt.show()  # Display image
